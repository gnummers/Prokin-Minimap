## v1.0.33
- Added comprehensive expense tracking system with multi-category support (repairs, postage, crafting, disenchanting)
- Implemented per-character ledgers with timestamped expense history and category breakdowns
- Added inventory worth calculation using TSM pricing or vendor fallback
- Simplified tooltip to show only GPH, Session net, and Daily net income
- Added new slash commands: `/pkm ledger`, `/pkm expenses`, `/pkm allcharacters`
- Automatic repair cost detection via `GetRepairAllCost()`
- Automatic postage detection via `GetSendMailPrice()`
- Crafting material cost tracking through inventory snapshots
- Disenchanting transaction detection via chat message parsing
- Maintained backward compatibility with existing tracking features

## v1.0.32
- Changed the persistent Daily Total so each character tracks its own total separately
- Kept the midnight server-time reset behavior for each character's daily total

## v1.0.31
- Added TSM-independent item pricing fallback so gold tracking still works without TradeSkillMaster installed
- Added visible TradeSkillMaster author credit in the options help text and documentation

## v1.0.30
- Fixed the mail visibility watchdog so it no longer recurses when the mail frame is hidden
- Kept the periodic mail visibility check and alpha restore without the direct hide hook loop

## v1.0.29
- Added a periodic mail visibility watchdog that re-shows the mail icon, restores alpha, and keeps checking after reload if another addon hides it

## v1.0.28
- Hardened the Blizzard mail icon so it re-evaluates on inbox updates and re-shows itself if another addon hides it while unread mail exists
- Added one-time mail visibility hooks so the mail frame keeps correcting itself without accumulating duplicate hooks

## v1.0.27
- Added a digital-clock safeguard that suppresses the circular minimap sundial icon (`GameTimeFrame`) whenever it appears
- Forces Prokin Minimap to use the Blizzard digital minimap clock path so the clock consistently stays in the desired style

## v1.0.26
- Added a Prokin minimap button with left-click role checks, right-click options access, tooltip role display, and saved edge positioning
- Added an in-game options window for minimap size, addon button visibility, server-time display, minimap border visibility, and load-announcement toggles
- Restyled and resized the options UI, slider, and Prokin minimap button to better match the surrounding addon buttons and keep all option text within the window border
- Changed raid role display from per-player lines to summarized Tank, Healers, and DPS counts in the tooltip and raid role-check output

## v1.0.25
- Replaced the battleground proxy click path with Blizzard's native battlefield button so protected queue actions and the battleground confirmation dialog keep working
- Stopped hiding the Blizzard battlefield button so its dismiss and queue controls stay visible when the battleground countdown prompt appears

## v1.0.24
- Fixed the battleground or PvP proxy button so queue actions like `Leave Queue` stay on Blizzard's secure battlefield button path
- Reanchored the hidden Blizzard battlefield button to the saved proxy position so its native queue menu opens from the same place without tainting `AcceptBattlefieldPort()`

## v1.0.23
- Fixed the battleground or PvP proxy button so both left-click and right-click open Blizzard's queue menu while queued or ready to enter
- Preserved the active battleground button behavior so left-click still opens the scoreframe and right-click still opens the leave menu

## v1.0.22
- Deferred minimap refresh work that resizes the minimap while combat lockdown is active
- Reapplies the pending square minimap layout automatically after combat ends to avoid `ADDON_ACTION_BLOCKED`

## v1.0.21
- Lowered the Blizzard minimap clock by 5 pixels on the bottom edge so the square border no longer cuts through it
- Added a delayed, colorized load announcement that stays visible after `/reload`
- Fixed the load announcement to read the addon version correctly from the Anniversary metadata API and updated the message text formatting

## v1.0.20
- Fixed the Tracking proxy on TBC Anniversary's modern Blizzard minimap by opening the generated tracking menu directly on the proxy owner region
- Preserved Tracking drag behavior while moving menu activation onto Blizzard's required mouse-down flow and handling the menu system's global mouse event correctly
- Added an opt-in `/pkm trackingdebug` diagnostic toggle and changed tracking debug logging to default off for public builds

## v1.0.19
- Fixed the tracking proxy to open Blizzard's TBC tracking dropdown through `MiniMapTrackingDropDown` and reanchor it after the menu appears
- Matched the tracking proxy art to Blizzard's native TBC dimensions and tightened the widget overlap again to remove the last visible border gap

## v1.0.18
- Increased the Blizzard widget border overlap so the minimap icons sit closer to the square border art
- Switched the tracking proxy to Blizzard's exact TBC `MiniMapTracking` dropdown call for more reliable tracking-menu opening

## v1.0.17
- Switched the Blizzard proxy buttons to mouse-up activation so the tracking proxy follows the TBC control flow more closely
- Added explicit widget border overlap to eliminate the remaining visible gap between the square minimap border and Blizzard widgets

## v1.0.16
- Removed the visible pixel gap so the Blizzard minimap widgets sit flush against the square minimap border
- Improved tracking button detection so the proxy targets the first Blizzard tracking control that actually exposes a menu handler on TBC Anniversary
- Split the zone-header spacing from widget edge spacing so the zone name and server time label keep their 4 pixel top offset independently

## v1.0.15
- Fixed the draggable widget wrapper so it only hooks scripts a Blizzard frame actually supports on TBC Anniversary
- Resolved the `GameTimeFrame:GetScript()` and `MiniMapMailFrame:GetScript()` Lua errors caused by drag suppression logic probing missing `OnClick` handlers

## v1.0.14
- Fixed the tracking proxy button so clicking it opens Blizzard's tracking menu correctly
- Added saved left-drag positioning for the visible Blizzard minimap widgets around the outside edge of the square minimap border
- Preserves widget reordering across reloads and keeps the dragged widgets clamped to the square border

## v1.0.13
- Moved the tracking and LFG proxy buttons off the minimap itself so MinimapButtonButton no longer collects them into its tray
- Added a conditional PvP or battleground proxy button that only shows while Blizzard battlefield state is active
- Tightened the mail icon handling so it only shows when `HasNewMail()` reports unread mail

## v1.0.12
- Added always-visible Blizzard-style tracking and LFG proxy buttons outside the square minimap border
- Wired the tracking proxy to Blizzard's native tracking dropdown behavior and forwarded the LFG proxy to Blizzard queue handlers when available
- Stopped force-showing the PvP or battleground indicator so it only appears when Blizzard would normally display it

## v1.0.11
- Added MinimapButtonButton compatibility for the Blizzard tracking, LFG/queue, clock, mail, and PvP/battleground widgets
- Preserves the original widget methods so Prokin-Minimap can still reparent and anchor those frames even after MinimapButtonButton overrides them
- Writes those Blizzard widgets into the MinimapButtonButton blacklist so they stay out of its collected button tray on future loads

## v1.0.10
- Restored the Blizzard tracking, LFG/queue, clock, mail, and PvP/battleground minimap widgets
- Anchored those Blizzard widgets just outside the square minimap border
- Added re-anchoring hooks so Blizzard repositioning is corrected automatically
- Added `Blizzard_TimeManager` handling so the clock is re-anchored when it loads

## v1.0.9
- Added a Prokin-Minimap compatibility hook for AutoMarkAssist
- Repositions the `AMA_MinimapButton` to the square minimap edge without modifying AutoMarkAssist
- Updated README and release metadata for the new compatibility behavior

## v1.0.8
- Fixed the TBC Anniversary Lua error caused by calling Blizzard minimap button texture setters with `nil`
- Changed header suppression to clear and hide existing texture objects directly instead of using `Set*Texture(nil)`
- Updated release metadata for the compatibility fix

## v1.0.7
- Added a server-time suffix to the custom zone label
- Time displays in 12-hour format as `[HH:MM AM/PM]`
- Updated README and release metadata to document the new label format

## v1.0.6
- Fixed the minimap header suppression helper to handle Blizzard objects more safely at runtime
- Improved reliability of hiding the floating header chrome, red X, and duplicate zone text
- Updated README to reflect the pfUI-style custom zone label approach

## v1.0.5
- Expanded suppression of Blizzard minimap header elements
- Added broader handling for legacy and cluster-owned header widgets
- Improved attempts to stop the default zone header from reappearing

## v1.0.4
- Hardened the custom zone label replacement
- Improved Blizzard header suppression behavior
- Updated documentation for the custom zone label behavior

## v1.0.3
- Switched toward a custom minimap zone label approach
- Reduced reliance on Blizzard's default zone header
- Continued work on removing duplicate zone text and header chrome

## v1.0.2
- Added the first pass of minimap zone-header chrome cleanup
- Began removing the floating frame and close button around the zone name

## v1.0.1
- Added mousewheel zoom support for the minimap
- Matched the ElvUI-style zoom behavior for wheel up/down
- Applied zoom handling to both the normal minimap and hybrid minimap

## v1.0.0
- Initial public release
- Added ElvUI-style square minimap masking for TBC Anniversary
- Added persistent minimap resizing with a default size of `400x400`
- Added refresh hooks so the square minimap reapplies correctly
- Added hybrid minimap compatibility
- Added zone header spacing improvements
- Added a custom 1px black minimap border
- Added addon icon support and release packaging for GitHub/CurseForge
